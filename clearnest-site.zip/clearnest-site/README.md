# ClearNEST sajt

Statički sajt bez frameworka. Sav sadržaj je u `config.mjs`, a `node build.mjs` pravi gotove HTML stranice u `dist/`.

## Pokretanje
```
node build.mjs            # razvoj
node build.mjs --production   # odbija build dok je telefon privremen
npm run serve             # pregled na http://localhost:8080
```
Otpremite sadržaj foldera `dist/` na hosting (Cloudflare Pages, Netlify, Vercel ili običan hosting). `_headers` radi na Cloudflare Pages i Netlify; na Apache/Nginx postavite iste keš zaglavlja ručno i uključite gzip/brotli.

## Pre objave (build ispisuje listu)
1. `business`: pravi telefon, e-pošta, domen (`siteUrl`), radno vreme, `mapsUrl`, `reviewUrl`, `sameAs`.
2. `formEndpoint`: servis koji prima `multipart/form-data` sa fotografijama (Formspree, Web3Forms, Netlify Forms ili sopstveni). Dok je prazan, forma otvara WhatsApp poruku bez fotografija.
3. `prices`: zamenite orijentacione cene stvarnim. Kalkulator i tabele na stranicama koriste isti izvor. Pitanje o ugaonoj garnituri u `services` ima cenu upisanu u tekstu, pa je ažurirajte i tamo.
4. `cities`: dodajte samo gradove u kojima zaista radite, stavite `draft: false`, popunite naselja i uslove dolaska. Svaki grad treba da ima stvarne lokalne detalje (ne kopirani tekst), inače Google takve stranice tretira kao „doorway”.
5. `reviews` i `gallery`: samo prave recenzije (uz dozvolu) i prave fotografije (WebP, stavite u `static/img/gal/`). Dok su prazni, sekcije i ocene u schema podacima se ne prikazuju.
6. Pravnik neka pregleda `/politika-privatnosti/`.

## Šta je ugrađeno
- Stranice: početna, 7 usluga, hub usluga, područja (po gradu), pitanja, kontakt i procena, privatnost, 404.
- Structured data (JSON-LD): LocalBusiness, WebSite, Service, FAQPage, BreadcrumbList, Review/AggregateRating (samo kad ima pravih recenzija).
- `sitemap.xml`, `robots.txt` (dozvoljeni i AI crawleri), `llms.txt`, canonical, Open Graph, `lang="sr-Latn"`.
- Hero: WebP poster odmah; 3D model i `hero3d.js` (590 KB) se učitavaju tek kad posetilac klikne „Pokreni 3D prikaz”, pauziraju se van ekrana i poštuju `prefers-reduced-motion`.
- Bez JavaScript-a: sav sadržaj, FAQ (`<details>`), meni i cene su vidljivi; forma se tada koristi samo preko telefona/WhatsApp-a.

## Google Business Profile (ručni koraci)
1. Kategorija: izaberite glavnu (npr. „Usluga čišćenja tepiha / nameštaja”), dodajte sporedne za svaku uslugu.
2. Tip: ako ne primate goste, podesite „service-area business” i sakrijte adresu; navedite gradove i naselja iz `cities`.
3. Isti naziv, telefon i sajt kao u `config.mjs` (NAP mora da se poklapa svuda).
4. Dodajte sve usluge sa opisom i orijentacionim cenama, radno vreme i fotografije (pre/posle, mašina, tim).
5. Link sajta: `https://…/?utm_source=google&utm_medium=organic&utm_campaign=gbp`.
6. Link za recenzije stavite u `reviewUrl`; tražite recenziju od svakog zadovoljnog klijenta u poruci posle posla.
7. Objavljujte objave (pre/posle, ponude) jednom nedeljno i odgovarajte na svaku recenziju.
8. Posle objave sajta: Google Search Console (dodajte sajt, pošaljite `sitemap.xml`) i Bing Webmaster Tools.

## Napomene
- FAQPage schema je ispravno označen, ali Google je 2023. ograničio prikaz FAQ rich rezultata uglavnom na državne i zdravstvene sajtove. Vrednost je u tome što AI pretraga i pomoćnici lakše citiraju jasna pitanja i odgovore.
- Nijedna tehnika ne garantuje poziciju. Najveći uticaj imaju stvarne recenzije, uređen GBP, stranice po gradovima sa stvarnim sadržajem i linkovi sa lokalnih sajtova i imenika.
