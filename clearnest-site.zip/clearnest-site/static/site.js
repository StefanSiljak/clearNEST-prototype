(function(){
'use strict';
var $=function(s,r){return (r||document).querySelector(s)},$$=function(s,r){return Array.prototype.slice.call((r||document).querySelectorAll(s))};
var rs=function(n){return n.toLocaleString('sr-Latn-RS')};

/* ---------- Hero: poster odmah, 3D se sam učitava posle prvog prikaza i nastavlja iz istog kadra ---------- */
(function(){
  var cv=$('#hero3d'),poster=$('#poster'),stage=$('#stage');
  if(!cv||!poster)return;
  var reduce=matchMedia('(prefers-reduced-motion: reduce)').matches,c=navigator.connection||{},cores=navigator.hardwareConcurrency||8,mem=navigator.deviceMemory||8;
  if(c.saveData||/(^|-)2g$/.test(c.effectiveType||'')||mem<=1||cores<=1)return; // slab uređaj ili veza: ostaje poster
  var H=null,visible=true;
  function boot(){
    var s=document.createElement('script');s.src='/hero3d.js';s.async=true;
    s.onload=function(){
      try{
        ClearNestHero.mount(cv,{modelUrl:'/puzzi-clean.glb',lowPower:cores<=4,allowSoftware:/[?&]soft=1/.test(location.search),onLowPerf:function(){cv.classList.remove('on');poster.style.visibility='visible'}}).then(function(h){H=h;return H.ready}).then(function(){
          H.seek(4.6); // isti kadar kao poster, bez skoka
          requestAnimationFrame(function(){cv.classList.add('on');poster.style.visibility='hidden';if(!reduce)H.start()});
          if('IntersectionObserver' in window){new IntersectionObserver(function(e){visible=e[0].isIntersecting;if(H&&!reduce){visible?H.start():H.stop()}}).observe(stage)}
        }).catch(function(){});
      }catch(e){}
    };
    document.head.appendChild(s);
  }
  function later(){'requestIdleCallback' in window?requestIdleCallback(boot,{timeout:3000}):setTimeout(boot,1500)}
  document.readyState==='complete'?setTimeout(later,2000):addEventListener('load',function(){setTimeout(later,2000)});
})();

/* ---------- Pre / posle slider ---------- */
$$('.ba').forEach(function(b){
  var r=$('input',b),a=$('.after',b);
  var f=function(){a.style.clipPath='inset(0 0 0 '+r.value+'%)'};
  r.addEventListener('input',f);f();
});

/* ---------- Kalkulator + forma ---------- */
var form=$('#procena');
if(!form)return;
var P=JSON.parse($('#prices-data').textContent);
var steps=$$('fieldset[data-step]',form),cur=0,stepper=$$('.stepper li',form);
var est=$('#est-out'),estField=$('#f-procena'),summaryField=$('#f-rezime');
var status=$('.status',form);

function showStep(i,quiet){
  cur=i;steps.forEach(function(s,k){s.hidden=k!==i});
  stepper.forEach(function(s,k){k===i?s.setAttribute('aria-current','step'):s.removeAttribute('aria-current')});
  if(i===2)calc();
  var h=quiet?null:$('legend',steps[i]);if(h){h.setAttribute('tabindex','-1');h.focus({preventScroll:false})}
}
function cat(){var r=$('input[name=kategorija]:checked',form);return r?r.value:''}
function syncCat(){
  var k=cat();
  $$('[data-for]',form).forEach(function(d){var on=d.getAttribute('data-for')===k;d.hidden=!on;$$('input,select',d).forEach(function(x){x.disabled=!on})});
}
function calc(){
  var k=cat(),lo=0,hi=0,txt='';
  if(k==='namestaj'){
    var t=$('#f-tip').value,q=Math.max(1,parseInt($('#f-kom').value,10)||1),j=Math.max(0,parseInt($('#f-jast').value,10)||0),it=P.namestaj[t];
    lo=it.range[0]*q+P.jastuk[0]*j;hi=it.range[1]*q+P.jastuk[1]*j;
    txt=it.label+' × '+q+(j?' + jastuka: '+j:'');
  }else if(k==='auto'){
    var cl=$('#f-klasa').value,ob=$('#f-obim').value,a=P.auto[cl];
    lo=a[ob][0];hi=a[ob][1];txt=a.label+', '+(ob==='komplet'?'kompletan enterijer':'samo sedišta');
  }else if(k==='tepih'){
    var m=Math.max(1,parseFloat($('#f-m2').value)||1);
    lo=Math.max(P.tepih.minimum,Math.round(P.tepih.perM2[0]*m));hi=Math.max(P.tepih.minimum,Math.round(P.tepih.perM2[1]*m));txt='Tepih / itison, '+m+' m²';
  }
  var out=lo?(lo===hi?rs(lo):rs(lo)+' – '+rs(hi))+' RSD':'—';
  est.textContent=out;estField.value=out;summaryField.value=txt;
}
form.addEventListener('input',function(e){if(e.target.name==='kategorija')syncCat();if(cur===2)calc()});
form.addEventListener('change',function(e){if(e.target.name==='kategorija')syncCat()});

$$('[data-next]',form).forEach(function(b){b.addEventListener('click',function(){
  var s=steps[cur],bad=$$('input,select,textarea',s).filter(function(x){return !x.disabled&&!x.checkValidity()})[0];
  if(bad){bad.reportValidity();return}
  showStep(Math.min(cur+1,steps.length-1));
})});
$$('[data-prev]',form).forEach(function(b){b.addEventListener('click',function(){showStep(Math.max(cur-1,0))})});

/* fotografije: pregled, najviše 3 */
var file=$('#f-foto'),thumbs=$('.thumbs',form);
file.addEventListener('change',function(){
  thumbs.textContent='';
  var fs=Array.prototype.slice.call(file.files).slice(0,3);
  if(file.files.length>3){var dt=new DataTransfer();fs.forEach(function(f){dt.items.add(f)});file.files=dt.files}
  fs.forEach(function(f){var i=new Image();i.alt='Izabrana fotografija: '+f.name;i.src=URL.createObjectURL(f);i.onload=function(){URL.revokeObjectURL(i.src)};thumbs.appendChild(i)});
});

function say(msg){status.textContent=msg;status.classList.add('on');status.setAttribute('tabindex','-1');status.focus()}

form.addEventListener('submit',function(e){
  e.preventDefault();
  if(!form.checkValidity()){form.reportValidity();return}
  if($('.hp input',form).value)return; // bot
  var d=new FormData(form);
  var btn=$('button[type=submit]',form);
  if(form.getAttribute('data-endpoint')){
    btn.disabled=true;
    fetch(form.getAttribute('data-endpoint'),{method:'POST',body:d,headers:{Accept:'application/json'}}).then(function(r){
      if(!r.ok)throw 0;
      say('Hvala na poslatim podacima! Pregledamo upit i javljamo vam tačnu cenu i slobodne termine u roku od '+form.getAttribute('data-minutes')+' minuta.');
      form.reset();syncCat();thumbs.textContent='';
    }).catch(function(){say('Slanje nije uspelo. Pozovite nas ili pošaljite fotografije na WhatsApp/Viber.')}).then(function(){btn.disabled=false});
  }else{
    var msg='Zdravo, tražim tačnu ponudu. '+summaryField.value+'. Okvirna procena: '+estField.value+'. Ime: '+d.get('ime')+'. Telefon: '+d.get('telefon')+'. Lokacija: '+d.get('lokacija')+'.'+(d.get('napomena')?' Napomena: '+d.get('napomena'):'');
    var wa=form.getAttribute('data-wa');
    if(wa){window.open('https://wa.me/'+wa.replace(/\D/g,'')+'?text='+encodeURIComponent(msg),'_blank','noopener')}
    say('Otvorili smo WhatsApp sa vašim upitom. Fotografije pošaljite u razgovoru, a mi odgovaramo u roku od '+form.getAttribute('data-minutes')+' minuta.');
  }
});

/* prefill iz linka: ?usluga=auto */
var q=/[?&]usluga=(namestaj|auto|tepih)/.exec(location.search);
if(q){var r=$('input[name=kategorija][value='+q[1]+']',form);if(r)r.checked=true}
syncCat();showStep(0,true);
})();
