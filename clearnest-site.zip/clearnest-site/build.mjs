// Generator statičkog sajta. Pokretanje: node build.mjs [--production]
import { mkdirSync, writeFileSync, cpSync, rmSync, existsSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { business as B, cities as ALL_CITIES, prices, money, services, faq as GENERAL_FAQ, benefits, reviews, gallery } from './config.mjs';

const ROOT = dirname(fileURLToPath(import.meta.url));
const OUT = join(ROOT, 'dist');
const PROD = process.argv.includes('--production');
const TODAY = new Date().toISOString().slice(0, 10);
const URL_ = B.siteUrl.replace(/\/$/, '');
const cities = ALL_CITIES.filter((c) => !c.draft);

const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const abs = (p) => URL_ + p;
const tel = `tel:${B.phone}`;
const wa = B.whatsapp ? `https://wa.me/${B.whatsapp.replace(/\D/g, '')}` : '';
const viber = B.viber ? `viber://chat?number=%2B${B.viber.replace(/\D/g, '')}` : '';

/* ---------- ikone (inline, bez zahteva ka mreži) ---------- */
const S = 'fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"';
const ICONS = {
  sofa: `<svg class="ico" viewBox="0 0 48 48" ${S} aria-hidden="true"><path d="M9 22v-5a5 5 0 0 1 5-5h20a5 5 0 0 1 5 5v5"/><path d="M5 25a4 4 0 0 1 8 0v4h22v-4a4 4 0 0 1 8 0v9H5z"/><path d="M12 34v3M36 34v3"/></svg>`,
  bed: `<svg class="ico" viewBox="0 0 48 48" ${S} aria-hidden="true"><path d="M6 36V12M6 28h36v8M42 28v-5a5 5 0 0 0-5-5H20v10"/><circle cx="13" cy="22" r="3.5"/></svg>`,
  rug: `<svg class="ico" viewBox="0 0 48 48" ${S} aria-hidden="true"><path d="M8 14h32l4 20H4z"/><path d="M13 20h22l2.5 9h-27z"/><path d="M4 34h-1M44 34h1"/></svg>`,
  chair: `<svg class="ico" viewBox="0 0 48 48" ${S} aria-hidden="true"><path d="M14 8h20v18H14z"/><path d="M11 26h26v6H11zM15 32v10M33 32v10"/></svg>`,
  car: `<svg class="ico" viewBox="0 0 48 48" ${S} aria-hidden="true"><path d="M6 30v-6l5-9h26l5 9v6z"/><path d="M6 24h36M10 30v4M38 30v4"/><circle cx="14" cy="27" r="1"/><circle cx="34" cy="27" r="1"/></svg>`,
  shop: `<svg class="ico" viewBox="0 0 48 48" ${S} aria-hidden="true"><path d="M7 20l3-10h28l3 10"/><path d="M7 20a5.7 5.7 0 0 0 11 0 5.7 5.7 0 0 0 12 0 5.7 5.7 0 0 0 11 0M10 24v16h28V24M20 40V30h8v10"/></svg>`,
  armchair: `<svg class="ico" viewBox="0 0 48 48" ${S} aria-hidden="true"><path d="M14 22v-6a8 8 0 0 1 20 0v6"/><path d="M8 24a4 4 0 0 1 8 0v6h16v-6a4 4 0 0 1 8 0v10H8z"/><path d="M13 34v6M35 34v6"/></svg>`,
};
const SVC_ICON = {
  'dubinsko-pranje-namestaja': 'armchair', 'ciscenje-dusek': 'bed', 'ciscenje-tepiha-i-itisona': 'rug',
  'ciscenje-troseda-dvoseda-i-ugaonih-garnitura': 'sofa', 'ciscenje-stolica-i-separea': 'chair',
  'ciscenje-enterijera-automobila': 'car', 'ciscenje-lokala-i-poslovnih-prostora': 'shop',
};
const I_PHONE = `<svg viewBox="0 0 24 24" ${S} aria-hidden="true"><path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2z"/></svg>`;
const I_CHAT = `<svg viewBox="0 0 24 24" ${S} aria-hidden="true"><path d="M4 5h16v11H9l-5 4z"/></svg>`;

/* ---------- strukturirani podaci ---------- */
const areaServed = () => cities.length ? cities.map((c) => ({ '@type': 'City', name: c.name })) : { '@type': 'Country', name: 'Srbija' };
function businessNode(full) {
  if (!full) return { '@id': abs('/#business') };
  const n = {
    '@type': 'LocalBusiness', '@id': abs('/#business'), name: B.name, legalName: B.legalName, url: abs('/'),
    image: abs('/og.jpg'), logo: abs('/logo.png'), description: 'Profesionalno dubinsko čišćenje nameštaja, dušeka, tepiha, itisona i enterijera automobila na vašoj adresi.',
    telephone: B.phone, email: B.email, priceRange: B.priceRange, areaServed: areaServed(),
    openingHoursSpecification: B.hours.map((h) => ({ '@type': 'OpeningHoursSpecification', dayOfWeek: h.days, opens: h.opens, closes: h.closes })),
    hasOfferCatalog: { '@type': 'OfferCatalog', name: 'Usluge čišćenja', itemListElement: services.map((s) => ({ '@type': 'Offer', itemOffered: { '@type': 'Service', name: s.name, url: abs(`/usluge/${s.slug}/`) } })) },
  };
  if (B.address.locality) n.address = { '@type': 'PostalAddress', streetAddress: B.address.street, addressLocality: B.address.locality, postalCode: B.address.postalCode, addressRegion: B.address.region, addressCountry: B.address.country };
  if (B.geo) n.geo = { '@type': 'GeoCoordinates', latitude: B.geo.lat, longitude: B.geo.lng };
  const same = [...B.sameAs, B.mapsUrl].filter(Boolean);
  if (same.length) n.sameAs = same;
  if (reviews.length) {
    n.aggregateRating = { '@type': 'AggregateRating', ratingValue: (reviews.reduce((a, r) => a + r.rating, 0) / reviews.length).toFixed(1), reviewCount: reviews.length, bestRating: 5 };
    n.review = reviews.map((r) => ({ '@type': 'Review', author: { '@type': 'Person', name: r.author }, datePublished: r.date, reviewBody: r.text, reviewRating: { '@type': 'Rating', ratingValue: r.rating, bestRating: 5 } }));
  }
  return n;
}
const crumbSchema = (items) => ({ '@type': 'BreadcrumbList', itemListElement: items.map(([name, path], i) => ({ '@type': 'ListItem', position: i + 1, name, item: abs(path) })) });
const faqSchema = (list) => ({ '@type': 'FAQPage', mainEntity: list.map(([q, a]) => ({ '@type': 'Question', name: q, acceptedAnswer: { '@type': 'Answer', text: a } })) });

/* ---------- delovi stranice ---------- */
const navLinks = [['/usluge/', 'Usluge'], ...(cities.length ? [['/podrucja/', 'Područja']] : []), ['/pitanja/', 'Pitanja'], ['/kontakt/', 'Kontakt']];

function header(cur) {
  const links = navLinks.map(([h, t]) => `<a href="${h}"${cur && cur.startsWith(h) ? ' aria-current="page"' : ''}>${t}</a>`).join('');
  return `<a class="skip" href="#sadrzaj">Pređi na sadržaj</a>
<header class="top"><div class="wrap bar">
<a class="brand" href="/" aria-label="${B.name}, početna strana"><b>clear<i>NEST</i></b><small>Dubinsko čišćenje</small></a>
<nav class="nav" aria-label="Glavna navigacija">${links}</nav>
<a class="btn p sm bar-cta" href="${tel}">${I_PHONE}${esc(B.phoneDisplay)}</a>
<details class="menu"><summary aria-label="Otvori meni">Meni</summary><nav aria-label="Mobilna navigacija">${links}<a href="${tel}">Pozovi: ${esc(B.phoneDisplay)}</a></nav></details>
</div></header>`;
}
function footer() {
  const sv = services.map((s) => `<li><a href="/usluge/${s.slug}/">${esc(s.name)}</a></li>`).join('');
  const ar = cities.map((c) => `<li><a href="/podrucja/${c.slug}/">Čišćenje ${esc(c.in)}</a></li>`).join('');
  const addr = B.address.locality ? `<p>${esc(B.address.street)}${B.address.street ? ', ' : ''}${esc(B.address.postalCode)} ${esc(B.address.locality)}</p>` : '<p>Dolazimo na vašu adresu.</p>';
  return `<footer><div class="wrap"><div class="fgrid">
<div><h2>${B.name}</h2>${addr}<p><a href="${tel}">${esc(B.phoneDisplay)}</a><br><a href="mailto:${esc(B.email)}">${esc(B.email)}</a></p><p>${esc(B.hoursText)}</p>${wa ? `<p><a href="${wa}" rel="noopener">WhatsApp</a>${viber ? ` · <a href="${viber}">Viber</a>` : ''}</p>` : ''}</div>
<div><h2>Usluge</h2><ul>${sv}</ul></div>
<div><h2>Informacije</h2><ul><li><a href="/pitanja/">Česta pitanja</a></li><li><a href="/kontakt/">Kontakt i procena</a></li>${ar}${B.mapsUrl ? `<li><a href="${esc(B.mapsUrl)}" rel="noopener">Pronađite nas na mapi</a></li>` : ''}${B.reviewUrl ? `<li><a href="${esc(B.reviewUrl)}" rel="noopener">Ostavite recenziju</a></li>` : ''}<li><a href="/politika-privatnosti/">Politika privatnosti</a></li></ul></div>
</div><p class="fine">© ${new Date().getFullYear()} ${esc(B.legalName)}. Sva prava zadržana.</p></div></footer>
<div class="dock" role="group" aria-label="Brzi kontakt"><a href="${tel}">${I_PHONE}Pozovi</a>${wa ? `<a class="w" href="${wa}" rel="noopener">${I_CHAT}WhatsApp</a>` : ''}${viber ? `<a class="v" href="${viber}">${I_CHAT}Viber</a>` : ''}</div>`;
}
const crumbsHtml = (items) => `<nav class="crumbs wrap" aria-label="Putanja"><ol>${items.map(([n, p], i) => i === items.length - 1 ? `<li aria-current="page">${esc(n)}</li>` : `<li><a href="${p}">${esc(n)}</a></li>`).join('')}</ol></nav>`;

function faqHtml(list, idp = 'q') {
  return `<div class="faq">${list.map(([q, a]) => `<details><summary>${esc(q)}</summary><p>${esc(a)}</p></details>`).join('')}</div>`;
}

function priceRows(svc) {
  const rows = (svc.priceKeys || []).map((k) => [prices.namestaj[k].label, money(prices.namestaj[k].range)]);
  if (svc.priceNote === 'tepih') rows.push(['Tepih / itison (po m²)', `${prices.tepih.perM2[0]} – ${prices.tepih.perM2[1]} RSD`], ['Minimalna porudžbina', `${prices.tepih.minimum.toLocaleString('sr-Latn-RS')} RSD`]);
  if (svc.priceNote === 'auto') Object.values(prices.auto).forEach((a) => rows.push([`${a.label}, samo sedišta`, money(a.sedista)], [`${a.label}, kompletan enterijer`, money(a.komplet)]));
  return rows;
}
const priceTable = (rows) => rows.length ? `<table><caption class="note" style="text-align:left;caption-side:bottom;padding-top:8px">Okvirne cene. Konačna cena zavisi od zaprljanosti i tačnih dimenzija.</caption><thead><tr><th scope="col">Usluga</th><th scope="col">Cena</th></tr></thead><tbody>${rows.map(([a, b]) => `<tr><td>${esc(a)}</td><td>${esc(b)}</td></tr>`).join('')}</tbody></table>` : '';

function calcForm() {
  const opt = (o, sel) => Object.entries(o).map(([k, v]) => `<option value="${k}">${esc(v.label)}</option>`).join('');
  const ep = B.formEndpoint ? ` action="${esc(B.formEndpoint)}" data-endpoint="${esc(B.formEndpoint)}"` : ' action="#procena"';
  return `<section class="sec alt" id="procena-sekcija" aria-labelledby="procena-h"><div class="wrap narrow">
<p class="eyebrow">besplatno i bez obaveze</p><h2 id="procena-h">Besplatna procena cene</h2>
<p class="lead">Izaberite uslugu, dobijte okvirnu cenu odmah, a tačnu ponudu šaljemo u roku od ${B.responseMinutes} minuta nakon što pošaljete fotografije.</p>
<form id="procena" class="calc" method="post" enctype="multipart/form-data"${ep} data-wa="${esc(B.whatsapp)}" data-minutes="${B.responseMinutes}" style="margin-top:22px">
<ol class="stepper" aria-label="Koraci"><li>Usluga</li><li>Detalji</li><li>Procena</li><li>Fotografije</li><li>Kontakt</li></ol>
<fieldset data-step="1"><legend>1. Šta čistimo?</legend><div class="radios" role="radiogroup">
<label><input type="radio" name="kategorija" value="namestaj" checked> Nameštaj</label>
<label><input type="radio" name="kategorija" value="auto"> Auto-enterijer</label>
<label><input type="radio" name="kategorija" value="tepih"> Tepisi / itison</label></div>
<p class="hint" style="margin-top:12px">Dušeci, garniture, fotelje i stolice spadaju u nameštaj.</p>
<div class="nav-btns"><button class="btn p" type="button" data-next>Dalje</button></div></fieldset>

<fieldset data-step="2"><legend>2. Detalji</legend>
<div data-for="namestaj"><div class="row2"><div class="field"><label for="f-tip">Vrsta</label><select id="f-tip" name="vrsta">${opt(prices.namestaj)}</select></div>
<div class="field"><label for="f-kom">Broj komada</label><input id="f-kom" name="komada" type="number" inputmode="numeric" min="1" max="50" value="1"></div></div>
<div class="field"><label for="f-jast">Dodatno: dekorativni jastučići (komada)</label><input id="f-jast" name="jastuci" type="number" inputmode="numeric" min="0" max="50" value="0"></div></div>
<div data-for="auto" hidden><div class="row2"><div class="field"><label for="f-klasa">Klasa vozila</label><select id="f-klasa" name="klasa">${opt(prices.auto)}</select></div>
<div class="field"><label for="f-obim">Obim</label><select id="f-obim" name="obim"><option value="sedista">Samo sedišta</option><option value="komplet">Komplet enterijer (sedišta, pod, gepek, vrata)</option></select></div></div></div>
<div data-for="tepih" hidden><div class="field"><label for="f-m2">Površina (m²)</label><input id="f-m2" name="m2" type="number" inputmode="decimal" min="1" max="500" step="0.5" value="6"></div></div>
<div class="nav-btns"><button class="btn s" type="button" data-prev>Nazad</button><button class="btn p" type="button" data-next>Dalje</button></div></fieldset>

<fieldset data-step="3"><legend>3. Okvirna procena</legend>
<div class="est" aria-live="polite"><span class="hint">Okvirna procena</span><strong id="est-out">Izaberite uslugu iznad</strong></div>
<p class="hint">Konačna cena zavisi od stepena zaprljanosti i tačnih dimenzija. Pogledajte i <a href="/usluge/">cenovnik po uslugama</a>.</p>
<input type="hidden" id="f-procena" name="procena"><input type="hidden" id="f-rezime" name="rezime">
<div class="nav-btns"><button class="btn s" type="button" data-prev>Nazad</button><button class="btn p" type="button" data-next>Za tačnu ponudu</button></div></fieldset>

<fieldset data-step="4"><legend>4. Fotografije (za tačnu cenu)</legend>
<div class="field"><label for="f-foto">Učitajte 1–3 fotografije iz različitih uglova</label><input id="f-foto" name="fotografije" type="file" accept="image/*" multiple><span class="hint">Na telefonu možete odmah da slikate kamerom.</span><div class="thumbs"></div></div>
<div class="field"><label for="f-nap">Napomena</label><textarea id="f-nap" name="napomena" maxlength="600" placeholder="Na primer: postoji stara fleka od kafe na rukohvatu"></textarea></div>
<div class="nav-btns"><button class="btn s" type="button" data-prev>Nazad</button><button class="btn p" type="button" data-next>Dalje</button></div></fieldset>

<fieldset data-step="5"><legend>5. Kontakt podaci</legend>
<div class="field"><label for="f-ime">Ime i prezime</label><input id="f-ime" name="ime" autocomplete="name" required></div>
<div class="row2"><div class="field"><label for="f-tel">Broj telefona (Viber / WhatsApp)</label><input id="f-tel" name="telefon" type="tel" inputmode="tel" autocomplete="tel" required></div>
<div class="field"><label for="f-lok">Lokacija / naselje</label><input id="f-lok" name="lokacija" autocomplete="address-level2" required></div></div>
<div class="hp" aria-hidden="true"><label>Ne popunjavati<input name="website" tabindex="-1" autocomplete="off"></label></div>
<p class="hint">Slanjem pristajete na obradu podataka u svrhu ponude, prema <a href="/politika-privatnosti/">politici privatnosti</a>.</p>
<div class="nav-btns"><button class="btn s" type="button" data-prev>Nazad</button><button class="btn p" type="submit">Pošalji i zatraži tačnu ponudu</button></div>
<div class="status" role="status" aria-live="polite"></div></fieldset>
</form>
<noscript><p class="note">Za slanje upita pozovite <a href="${tel}">${esc(B.phoneDisplay)}</a>${wa ? ` ili pišite na <a href="${wa}">WhatsApp</a>` : ''}.</p></noscript>
<script type="application/json" id="prices-data">${JSON.stringify({ namestaj: Object.fromEntries(Object.entries(prices.namestaj).map(([k, v]) => [k, { label: v.label, range: v.range }])), jastuk: prices.jastuk, auto: prices.auto, tepih: prices.tepih })}</script>
</div></section>`;
}

function galleryHtml() {
  if (!gallery.length) return '';
  return `<section class="sec" aria-labelledby="gal-h"><div class="wrap"><h2 id="gal-h">Pre i posle</h2><p class="lead">Stvarni rezultati naših čišćenja.</p><div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:22px;margin-top:22px">${gallery.map((g, i) => `<figure style="margin:0">
<div class="ba-js"><div class="ba"><img src="${esc(g.before)}" alt="Pre čišćenja: ${esc(g.alt)}" width="${g.w}" height="${g.h}" loading="lazy" decoding="async"><img class="after" src="${esc(g.after)}" alt="Posle čišćenja: ${esc(g.alt)}" width="${g.w}" height="${g.h}" loading="lazy" decoding="async"><span class="tag b">Pre</span><span class="tag a">Posle</span><input type="range" min="0" max="100" value="50" aria-label="Pomerite da uporedite pre i posle: ${esc(g.caption)}"></div></div>
<div class="nojs-ba"><img src="${esc(g.before)}" alt="Pre čišćenja: ${esc(g.alt)}" width="${g.w}" height="${g.h}" loading="lazy" decoding="async"><img src="${esc(g.after)}" alt="Posle čišćenja: ${esc(g.alt)}" width="${g.w}" height="${g.h}" loading="lazy" decoding="async"></div>
<figcaption class="note" style="margin-top:8px">${esc(g.caption)}</figcaption></figure>`).join('')}</div></div></section>`;
}
function reviewsHtml() {
  if (!reviews.length) return '';
  return `<section class="sec alt" aria-labelledby="rec-h"><div class="wrap"><h2 id="rec-h">Utisci klijenata</h2><ul class="cards">${reviews.map((r) => `<li><figure class="card" style="margin:0"><blockquote style="margin:0"><p>„${esc(r.text)}”</p></blockquote><figcaption><strong>${esc(r.author)}</strong> · ${'★'.repeat(r.rating)}<span class="sr" style="position:absolute;left:-9999px"> ocena ${r.rating} od 5</span></figcaption></figure></li>`).join('')}</ul>${B.reviewUrl ? `<p style="margin-top:18px"><a class="btn s" href="${esc(B.reviewUrl)}" rel="noopener">Ostavite recenziju na Google-u</a></p>` : ''}</div></section>`;
}
const serviceCards = () => `<ul class="cards">${services.map((s) => `<li><a class="card" href="/usluge/${s.slug}/">${ICONS[SVC_ICON[s.slug]]}<h3>${esc(s.name)}</h3><p>${esc(s.short)}</p><span class="more">Saznajte više →</span></a></li>`).join('')}</ul>`;
const howSteps = `<ol class="steps"><li><h3>Pošaljete fotografije</h3><p>Popunite procenu ili pišite na WhatsApp/Viber. Odgovaramo u roku od ${B.responseMinutes} minuta.</p></li><li><h3>Dogovorimo cenu i termin</h3><p>Dobijate tačnu cenu pre rada i termin koji vam odgovara.</p></li><li><h3>Dolazimo na vašu adresu</h3><p>Mašina za ekstrakciju nanosi rastvor i odmah usisava prljavštinu.</p></li><li><h3>Uživate u čistoći</h3><p>Nameštaj se suši za nekoliko sati, a mi dajemo savete za održavanje.</p></li></ol>`;

/* ---------- osnovni šablon ---------- */
function page({ path, title, desc, main, schema = [], noindex = false, hero = false, cur = '', ogType = 'website' }) {
  const canon = abs(path);
  const graph = { '@context': 'https://schema.org', '@graph': schema };
  return `<!doctype html>
<html lang="sr-Latn">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>${esc(title)}</title>
<meta name="description" content="${esc(desc)}">
<link rel="canonical" href="${canon}">
<meta name="robots" content="${noindex ? 'noindex,follow' : 'index,follow,max-image-preview:large,max-snippet:-1'}">
<meta name="theme-color" content="#FCF8F5">
<meta property="og:type" content="${ogType}"><meta property="og:site_name" content="${B.name}"><meta property="og:locale" content="sr_RS">
<meta property="og:title" content="${esc(title)}"><meta property="og:description" content="${esc(desc)}"><meta property="og:url" content="${canon}">
<meta property="og:image" content="${abs('/og.jpg')}"><meta property="og:image:width" content="1200"><meta property="og:image:height" content="630"><meta property="og:image:alt" content="ClearNEST, dubinsko čišćenje: kad čisto nije dovoljno">
<meta name="twitter:card" content="summary_large_image">
<link rel="icon" href="/favicon.svg" type="image/svg+xml"><link rel="apple-touch-icon" href="/apple-touch-icon.png">
<link rel="preload" href="/fonts/quicksand-latin-wght-normal.woff2" as="font" type="font/woff2" crossorigin>
${hero ? `<link rel="preload" as="image" href="/poster.webp" fetchpriority="high" media="(min-width:900px)">\n<link rel="preload" as="image" href="/poster-m.webp" fetchpriority="high" media="(max-width:899px)">` : ''}
<link rel="stylesheet" href="/site.css">
<script>document.documentElement.classList.add('js')</script>
<script type="application/ld+json">${JSON.stringify(graph)}</script>
</head>
<body>
${header(cur)}
<main id="sadrzaj">
${main}
</main>
${footer()}
<script src="/site.js" defer></script>
</body>
</html>
`;
}
const out = [];
const write = (p, html) => { const f = join(OUT, p.endsWith('/') ? p + 'index.html' : p); mkdirSync(dirname(f), { recursive: true }); writeFileSync(f, html); };
const sitemap = [];
function add(spec, opts = {}) {
  write(spec.path, page(spec));
  if (!spec.noindex) sitemap.push({ path: spec.path, pr: opts.pr ?? 0.7 });
}
const crumbPage = (items) => [crumbSchema(items)];

/* ---------- početna ---------- */
const homeFaq = GENERAL_FAQ.slice(0, 5);
add({
  path: '/', cur: '/', hero: true,
  title: 'Dubinsko čišćenje nameštaja, dušeka i tepiha | ClearNEST',
  desc: 'Profesionalno dubinsko pranje nameštaja, dušeka, tepiha i enterijera auta na vašoj adresi. Bezbedno za decu i ljubimce. Besplatna procena za 15 minuta.',
  schema: [businessNode(true), { '@type': 'WebSite', '@id': abs('/#website'), url: abs('/'), name: B.name, inLanguage: 'sr-Latn', publisher: { '@id': abs('/#business') } }, faqSchema(homeFaq)],
  main: `<section class="hero wrap" aria-labelledby="naslov"><div class="grid">
<div class="copy"><p class="eyebrow">${esc(B.tagline)}</p>
<h1 id="naslov">Profesionalno dubinsko pranje <em>nameštaja i vozila</em> na vašoj adresi</h1>
<p class="lead">Vraćamo svežinu i čistoću vašem domu. Brzo, efikasno i bezbedno za decu i kućne ljubimce.</p>
<div class="cta"><a class="btn p" href="${tel}">${I_PHONE}Pozovi odmah</a><a class="btn s" href="#procena-sekcija">Besplatna procena (kalkulator)</a></div>
<ul class="chips" aria-label="Šta čistimo"><li>Garniture</li><li>Dušeci</li><li>Tepisi</li><li>Auto-enterijer</li></ul></div>
<div class="stage" id="stage"><picture><source media="(max-width:899px)" srcset="/poster-m.webp" width="960" height="800"><img id="poster" src="/poster.webp" width="1200" height="960" alt="Mašina za dubinsko čišćenje čisti prljav tepih, ručica se kreće od gornjeg levog do donjeg desnog ugla" fetchpriority="high" decoding="async"></picture>
<canvas id="hero3d" aria-hidden="true"></canvas></div>
</div></section>
<section class="sec alt" aria-labelledby="zasto"><div class="wrap"><h2 id="zasto">Zašto ClearNEST</h2><ul class="benefits">${benefits.map(([t, d]) => `<li><h3>${esc(t)}</h3><p>${esc(d)}</p></li>`).join('')}</ul></div></section>
<section class="sec" id="usluge" aria-labelledby="usl-h"><div class="wrap"><h2 id="usl-h">Naše usluge</h2><p class="lead">Nameštaj, dušeci, tepisi, enterijer automobila i poslovni prostori. Sve na vašoj adresi.</p>${serviceCards()}</div></section>
<section class="sec alt" id="kako-radimo" aria-labelledby="kako-h"><div class="wrap narrow"><h2 id="kako-h">Kako radimo</h2>${howSteps}</div></section>
${galleryHtml()}
${calcForm()}
${reviewsHtml()}
<section class="sec" aria-labelledby="faq-h"><div class="wrap narrow"><h2 id="faq-h">Često postavljana pitanja</h2>${faqHtml(homeFaq)}<p><a href="/pitanja/">Sva pitanja i odgovori →</a></p></div></section>
${cities.length ? `<section class="sec alt" aria-labelledby="pod-h"><div class="wrap"><h2 id="pod-h">Gde radimo</h2><p>${cities.map((c) => `<a class="pill" href="/podrucja/${c.slug}/">${esc(c.name)}</a>`).join('')}</p></div></section>` : ''}`,
}, { pr: 1.0 });

/* ---------- usluge ---------- */
const svcCrumbs = (s) => [['Početna', '/'], ['Usluge', '/usluge/'], [s.name, `/usluge/${s.slug}/`]];
add({
  path: '/usluge/', cur: '/usluge/',
  title: 'Usluge dubinskog čišćenja | ClearNEST',
  desc: 'Pregled usluga: dubinsko pranje nameštaja, dušeka, tepiha i itisona, garnitura, stolica i separea, enterijera automobila i poslovnih prostora.',
  schema: [businessNode(false), crumbSchema([['Početna', '/'], ['Usluge', '/usluge/']]), { '@type': 'ItemList', itemListElement: services.map((s, i) => ({ '@type': 'ListItem', position: i + 1, url: abs(`/usluge/${s.slug}/`), name: s.name })) }],
  main: `${crumbsHtml([['Početna', '/'], ['Usluge', '/usluge/']])}<div class="wrap page-head"><h1>Usluge dubinskog čišćenja</h1><p class="lead">Sve radimo na vašoj adresi mašinom za ekstrakciju, a cenu dogovaramo unapred.</p></div><section class="sec"><div class="wrap">${serviceCards()}</div></section>`,
}, { pr: 0.9 });

for (const s of services) {
  const crumbs = svcCrumbs(s);
  const related = s.related.map((r) => services.find((x) => x.slug === r)).filter(Boolean);
  const rows = priceRows(s);
  add({
    path: `/usluge/${s.slug}/`, cur: '/usluge/',
    title: s.metaTitle, desc: s.metaDesc,
    schema: [businessNode(false), crumbSchema(crumbs),
      { '@type': 'Service', '@id': abs(`/usluge/${s.slug}/#service`), name: s.name, serviceType: s.name, description: s.metaDesc, url: abs(`/usluge/${s.slug}/`), provider: { '@id': abs('/#business') }, areaServed: areaServed(), availableChannel: { '@type': 'ServiceChannel', serviceLocation: { '@type': 'Place', name: 'Na adresi klijenta' } } },
      faqSchema(s.faq)],
    main: `${crumbsHtml(crumbs)}
<div class="wrap page-head"><div class="two"><div><h1>${esc(s.h1)}</h1><p class="lead">${esc(s.lead)}</p><div class="cta"><a class="btn p" href="${tel}">${I_PHONE}Pozovi odmah</a><a class="btn s" href="/kontakt/?usluga=${s.slug.includes('automobil') ? 'auto' : s.slug.includes('tepih') ? 'tepih' : 'namestaj'}#procena-sekcija">Besplatna procena</a></div></div><div class="aside" aria-hidden="true" style="display:flex;justify-content:center;padding:30px"><span style="width:96px;height:96px;display:block">${ICONS[SVC_ICON[s.slug]].replace('class="ico"', 'style="width:96px;height:96px;color:var(--sage)"')}</span></div></div></div>
<section class="sec"><div class="wrap narrow">${s.body.map((p) => `<p>${esc(p)}</p>`).join('')}
<h2>Šta čistimo</h2><ul class="ticks">${s.includes.map((i) => `<li>${esc(i)}</li>`).join('')}</ul>
<h2 style="margin-top:36px">Kako izgleda postupak</h2><ol class="steps">${s.steps.map(([t, d]) => `<li><h3>${esc(t)}</h3><p>${esc(d)}</p></li>`).join('')}</ol>
${rows.length ? `<h2 style="margin-top:36px">Okvirne cene</h2>${priceTable(rows)}` : ''}
<h2 style="margin-top:36px">Česta pitanja</h2>${faqHtml(s.faq)}
<div class="related"><h2>Pogledajte i</h2><p>${related.map((r) => `<a class="pill" href="/usluge/${r.slug}/">${esc(r.name)}</a>`).join('')}</p></div>
</div></section>
<section class="sec alt"><div class="wrap narrow"><h2>Zatražite ponudu</h2><p>Pošaljite fotografije i dobijate tačnu cenu u roku od ${B.responseMinutes} minuta.</p><div class="cta"><a class="btn p" href="/kontakt/#procena-sekcija">Besplatna procena</a><a class="btn s" href="${tel}">Pozovi ${esc(B.phoneDisplay)}</a></div></div></section>`,
  }, { pr: 0.9 });
}

/* ---------- područja ---------- */
function cityPage(c) {
  const crumbs = [['Početna', '/'], ['Područja', '/podrucja/'], [c.name, `/podrucja/${c.slug}/`]];
  const zone = c.zone.join(', ');
  return {
    path: `/podrucja/${c.slug}/`, cur: '/podrucja/', noindex: !!c.draft,
    title: `Dubinsko čišćenje nameštaja ${c.in} | ${B.name}`.slice(0, 70),
    desc: `Dubinsko pranje garnitura, dušeka, tepiha i enterijera auta ${c.in}. Dolazimo na adresu: ${zone}. Besplatna procena za ${B.responseMinutes} minuta.`.slice(0, 158),
    schema: [businessNode(false), crumbSchema(crumbs), { '@type': 'Service', name: `Dubinsko čišćenje ${c.in}`, provider: { '@id': abs('/#business') }, areaServed: { '@type': 'City', name: c.name }, url: abs(`/podrucja/${c.slug}/`) }],
    main: `${crumbsHtml(crumbs)}<div class="wrap page-head"><h1>Dubinsko čišćenje nameštaja ${esc(c.in)}</h1><p class="lead">ClearNEST dolazi na vašu adresu ${esc(c.in)}: u ${esc(zone)} i okolna naselja. ${esc(c.arrival)}</p><div class="cta"><a class="btn p" href="${tel}">${I_PHONE}Pozovi odmah</a><a class="btn s" href="/kontakt/#procena-sekcija">Besplatna procena</a></div></div>
<section class="sec"><div class="wrap narrow"><h2>Šta čistimo ${esc(c.in)}</h2><p>Garniture, fotelje, dušeke, tepihe, itison i enterijer automobila, kao i kafiće, kancelarije i druge poslovne prostore. Radimo mašinom za ekstrakciju, pa se tekstil suši za nekoliko sati.</p>${serviceCards()}
<h2 style="margin-top:36px">Pitanja klijenata ${esc(c.in)}</h2>${faqHtml(GENERAL_FAQ.slice(2, 4))}</div></section>`,
  };
}
if (cities.length) add({
  path: '/podrucja/', cur: '/podrucja/', title: `Gde radimo: gradovi i naselja | ${B.name}`,
  desc: `Dubinsko čišćenje nameštaja, tepiha i dušeka u gradovima i naseljima: ${cities.map((c) => c.name).join(', ')}.`,
  schema: [businessNode(false), crumbSchema([['Početna', '/'], ['Područja', '/podrucja/']])],
  main: `${crumbsHtml([['Početna', '/'], ['Područja', '/podrucja/']])}<div class="wrap page-head"><h1>Gde radimo</h1><p class="lead">Dolazimo na vašu adresu. Izaberite grad za više informacija.</p></div><section class="sec"><div class="wrap"><ul class="cards">${cities.map((c) => `<li><a class="card" href="/podrucja/${c.slug}/"><h3>${esc(c.name)}</h3><p>${esc(c.zone.join(', '))}</p><span class="more">Detalji →</span></a></li>`).join('')}</ul></div></section>`,
}, { pr: 0.7 });
for (const c of ALL_CITIES) { const spec = cityPage(c); add(spec, { pr: 0.7 }); }

/* ---------- pitanja ---------- */
const allFaq = [...GENERAL_FAQ, ...services.flatMap((s) => s.faq)];
add({
  path: '/pitanja/', cur: '/pitanja/', title: 'Česta pitanja o dubinskom čišćenju | ClearNEST',
  desc: 'Odgovori na najčešća pitanja: koliko traje sušenje, da li je bezbedno za decu i ljubimce, da li se dolazak naplaćuje i šta pripremiti.',
  schema: [businessNode(false), crumbSchema([['Početna', '/'], ['Pitanja', '/pitanja/']]), faqSchema(allFaq)],
  main: `${crumbsHtml([['Početna', '/'], ['Pitanja', '/pitanja/']])}<div class="wrap page-head"><h1>Česta pitanja</h1></div><section class="sec"><div class="wrap narrow"><h2>Opšta pitanja</h2>${faqHtml(GENERAL_FAQ)}${services.map((s) => `<h2 style="margin-top:36px">${esc(s.name)}</h2>${faqHtml(s.faq)}`).join('')}</div></section>`,
}, { pr: 0.8 });

/* ---------- kontakt ---------- */
const contactCrumbs = [['Početna', '/'], ['Kontakt', '/kontakt/']];
add({
  path: '/kontakt/', cur: '/kontakt/', title: 'Kontakt i besplatna procena | ClearNEST',
  desc: `Pozovite ${B.phoneDisplay}, pišite na WhatsApp/Viber ili pošaljite fotografije za tačnu cenu u roku od ${B.responseMinutes} minuta.`,
  schema: [businessNode(true), crumbSchema(contactCrumbs), { '@type': 'ContactPage', url: abs('/kontakt/'), about: { '@id': abs('/#business') } }],
  main: `${crumbsHtml(contactCrumbs)}<div class="wrap page-head"><h1>Kontakt i besplatna procena</h1><p class="lead">Pozovite nas, pišite na WhatsApp ili Viber, ili pošaljite fotografije kroz formu.</p>
<div class="cta"><a class="btn p" href="${tel}">${I_PHONE}${esc(B.phoneDisplay)}</a>${wa ? `<a class="btn s" href="${wa}" rel="noopener">WhatsApp</a>` : ''}${viber ? `<a class="btn s" href="${viber}">Viber</a>` : ''}${B.mapsUrl ? `<a class="btn s" href="${esc(B.mapsUrl)}" rel="noopener">Otvori na mapi</a>` : ''}</div></div>
<section class="sec"><div class="wrap narrow"><h2>Podaci</h2><p>${esc(B.name)}<br>Telefon: <a href="${tel}">${esc(B.phoneDisplay)}</a><br>E-pošta: <a href="mailto:${esc(B.email)}">${esc(B.email)}</a><br>Radno vreme: ${esc(B.hoursText)}</p>${cities.length ? `<p>Radimo u: ${cities.map((c) => esc(c.name)).join(', ')}.</p>` : '<p>Dolazimo na vašu adresu.</p>'}</div></section>
${calcForm()}`,
}, { pr: 0.8 });

/* ---------- privatnost + 404 ---------- */
add({
  path: '/politika-privatnosti/', title: 'Politika privatnosti | ClearNEST', desc: 'Kako ClearNEST obrađuje podatke i fotografije koje pošaljete radi ponude.',
  schema: [businessNode(false), crumbSchema([['Početna', '/'], ['Politika privatnosti', '/politika-privatnosti/']])],
  main: `${crumbsHtml([['Početna', '/'], ['Politika privatnosti', '/politika-privatnosti/']])}<div class="wrap page-head"><h1>Politika privatnosti</h1></div><section class="sec"><div class="wrap narrow">
<p>Rukovalac podacima je ${esc(B.legalName)} (${esc(B.email)}). Kada pošaljete formu, obrađujemo ime, telefon, lokaciju, napomenu i fotografije isključivo radi pripreme ponude i dogovora termina.</p>
<p>Podatke čuvamo samo koliko je potrebno za tu svrhu i ne delimo ih sa trećim licima, osim pružaoca usluge slanja poruka/obrazaca koji koristimo. Fotografije ne objavljujemo bez vaše dozvole.</p>
<p>Imate pravo da zatražite uvid, ispravku ili brisanje svojih podataka na ${esc(B.email)}.</p>
<p class="note">Ovaj tekst je osnovna verzija i treba da ga pregleda pravnik pre objave (Zakon o zaštiti podataka o ličnosti).</p></div></section>`,
}, { pr: 0.2 });
write('/404.html', page({ path: '/404.html', title: 'Stranica nije pronađena | ClearNEST', desc: 'Tražena stranica ne postoji.', noindex: true, schema: [], main: `<div class="wrap page-head"><h1>Stranica nije pronađena</h1><p class="lead">Proverite adresu ili se vratite na <a href="/">početnu stranu</a>.</p></div>` }));

/* ---------- statički fajlovi, sitemap, robots, llms.txt ---------- */
cpSync(join(ROOT, 'static'), OUT, { recursive: true });
writeFileSync(join(OUT, 'favicon.svg'), `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><path d="M16 3C12 10 7 14 7 20a9 9 0 0 0 18 0c0-6-5-10-9-17z" fill="#93B5D6"/><path d="M16 12c-2.5 4-5 6-5 9a5 5 0 0 0 10 0c0-3-2.5-5-5-9z" fill="#7FA698"/></svg>`);
writeFileSync(join(OUT, 'sitemap.xml'), `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${sitemap.map((u) => `  <url><loc>${abs(u.path)}</loc><lastmod>${TODAY}</lastmod><priority>${u.pr.toFixed(1)}</priority></url>`).join('\n')}\n</urlset>\n`);
const bots = ['Googlebot', 'Bingbot', 'GPTBot', 'OAI-SearchBot', 'ChatGPT-User', 'ClaudeBot', 'Claude-SearchBot', 'PerplexityBot', 'Google-Extended', 'Applebot-Extended'];
writeFileSync(join(OUT, 'robots.txt'), `User-agent: *\nAllow: /\n\n${bots.map((b) => `User-agent: ${b}\nAllow: /\n`).join('\n')}\nSitemap: ${abs('/sitemap.xml')}\n`);
writeFileSync(join(OUT, 'llms.txt'), `# ${B.name}\n\n> Profesionalno dubinsko čišćenje nameštaja, dušeka, tepiha, itisona i enterijera automobila na adresi klijenta${cities.length ? ' (' + cities.map((c) => c.name).join(', ') + ')' : ''}. Radno vreme: ${B.hoursText}. Telefon: ${B.phoneDisplay}. Odgovor na upit sa fotografijama u roku od ${B.responseMinutes} minuta.\n\n## Usluge\n${services.map((s) => `- [${s.name}](${abs(`/usluge/${s.slug}/`)}): ${s.short}`).join('\n')}\n\n## Informacije\n- [Česta pitanja](${abs('/pitanja/')})\n- [Kontakt i besplatna procena](${abs('/kontakt/')})\n${cities.length ? `- [Područja](${abs('/podrucja/')})\n` : ''}`);
writeFileSync(join(OUT, '_headers'), `/*\n  X-Content-Type-Options: nosniff\n  Referrer-Policy: strict-origin-when-cross-origin\n  Permissions-Policy: camera=(), microphone=(), geolocation=()\n\n/fonts/*\n  Cache-Control: public, max-age=31536000, immutable\n/*.webp\n  Cache-Control: public, max-age=31536000, immutable\n/*.glb\n  Cache-Control: public, max-age=31536000, immutable\n/site.css\n  Cache-Control: public, max-age=86400\n/site.js\n  Cache-Control: public, max-age=86400\n/hero3d.js\n  Cache-Control: public, max-age=31536000, immutable\n`);

/* ---------- upozorenja ---------- */
const warn = [];
if (B.phone === '+381600000000') warn.push('Telefon je privremeni (config.mjs → business.phone).');
if (B.siteUrl.includes('clearnest.rs')) warn.push('siteUrl je pretpostavljen: potvrdite pravi domen.');
if (!B.formEndpoint) warn.push('formEndpoint je prazan: forma otvara WhatsApp umesto slanja fotografija.');
if (!B.mapsUrl) warn.push('mapsUrl (Google Business Profile) nije postavljen.');
if (!B.sameAs.length) warn.push('sameAs (društvene mreže) je prazan.');
if (!reviews.length) warn.push('Nema pravih recenzija: sekcija i AggregateRating su isključeni.');
if (!gallery.length) warn.push('Nema pre/posle fotografija: galerija je isključena.');
if (ALL_CITIES.some((c) => c.draft)) warn.push('Gradovi su draft (noindex, van sitemap-a) dok ne postavite draft:false.');
warn.push('Cene u config.mjs → prices su ORIJENTACIONE i moraju se zameniti stvarnim.');
console.log(`Gotovo: ${sitemap.length} stranica u sitemap-u → ${OUT}`);
warn.forEach((w) => console.log('  ! ' + w));
if (PROD && B.phone === '+381600000000') { console.error('Produkcijski build odbijen: telefon nije postavljen.'); process.exit(1); }
