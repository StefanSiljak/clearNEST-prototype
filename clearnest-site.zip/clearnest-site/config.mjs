// ClearNEST — SVI podaci sajta su ovde. Izmenite vrednosti pa pokrenite: node build.mjs --production
// Sve što je označeno "TODO" mora biti popunjeno pre objave (build --production prijavljuje šta fali).

export const business = {
  name: 'ClearNEST',
  legalName: 'ClearNEST',                          // TODO: pun naziv firme/preduzetnika kako piše u APR-u
  tagline: 'kad čisto nije dovoljno',
  siteUrl: 'https://www.clearnest.rs',             // TODO: pravi domen (bez kosa crte na kraju)
  phone: '+381600000000',                          // TODO: međunarodni format, bez razmaka
  phoneDisplay: '060 000 0000',                    // TODO: kako se prikazuje na sajtu
  whatsapp: '+381600000000',                       // TODO: broj za WhatsApp (ostavite '' ako ne koristite)
  viber: '+381600000000',                          // TODO: broj za Viber (ostavite '' ako ne koristite)
  email: 'info@clearnest.rs',                      // TODO
  // Adresa nije obavezna za firmu koja radi na adresi klijenta (service-area business). Ostavite '' da se ne prikazuje.
  address: { street: '', locality: '', postalCode: '', region: '', country: 'RS' },
  geo: null,                                       // npr. { lat: 44.8125, lng: 20.4612 }
  mapsUrl: '',                                     // TODO: link na Google Maps / GBP profil
  reviewUrl: '',                                   // TODO: link za ostavljanje Google recenzije (GBP → "Zatraži recenzije")
  sameAs: [],                                      // TODO: ['https://www.instagram.com/…', 'https://www.facebook.com/…', GBP url]
  // radno vreme: dani (schema.org), od, do
  hours: [
    { days: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'], opens: '08:00', closes: '20:00' },
  ],
  hoursText: 'Pon–Sub 08:00–20:00',               // TODO: isto, za ljude
  priceRange: 'RSD',
  // Gde šalje forma. '' = forma otvara WhatsApp/Viber poruku (bez fotografija).
  // Preporuka: Formspree / Web3Forms / Netlify Forms / sopstveni endpoint koji prima multipart/form-data.
  formEndpoint: '',
  responseMinutes: 15,
};

// Gradovi i naselja. draft:true = stranica se pravi sa noindex i ne ulazi u sitemap/schemu dok ne popunite podatke.
// NE objavljujte grad u kojem ne radite. Svaka stranica treba stvarne lokalne detalje (naselja, kvartovi, vreme dolaska).
export const cities = [
  { slug: 'beograd',   name: 'Beograd',   in: 'u Beogradu',   zone: ['Zvezdara', 'Vračar', 'Novi Beograd', 'Zemun'], arrival: 'Dolazak u gradsku zonu je besplatan.', draft: true },
  { slug: 'novi-sad',  name: 'Novi Sad',  in: 'u Novom Sadu', zone: ['Liman', 'Detelinara', 'Podbara', 'Petrovaradin'], arrival: 'Dolazak u gradsku zonu je besplatan.', draft: true },
  { slug: 'nis',       name: 'Niš',       in: 'u Nišu',       zone: ['Medijana', 'Pantelej', 'Palilula', 'Crveni Krst'], arrival: 'Dolazak u gradsku zonu je besplatan.', draft: true },
];

// ORIJENTACIONE cene u RSD [od, do]. TODO: zamenite stvarnim cenama pre objave.
export const prices = {
  namestaj: {
    ugaona:   { label: 'Ugaona garnitura',  range: [4500, 6500] },
    trosed:   { label: 'Trosed',            range: [3000, 4000] },
    dvosed:   { label: 'Dvosed',            range: [2200, 3000] },
    fotelja:  { label: 'Fotelja',           range: [1200, 1800] },
    dusek1:   { label: 'Dušek (jednosed)',  range: [2000, 2800] },
    dusek2:   { label: 'Dušek (bračni)',    range: [3000, 4000] },
    stolica:  { label: 'Stolica (po komadu)', range: [300, 500] },
  },
  jastuk: [150, 250],
  auto: {
    mali:   { label: 'Malo gradsko vozilo', sedista: [4000, 5500], komplet: [7000, 9000] },
    limuzina: { label: 'Limuzina',          sedista: [5000, 6500], komplet: [8500, 11000] },
    suv:    { label: 'SUV / monovolumen',   sedista: [6000, 8000], komplet: [10000, 14000] },
  },
  tepih: { perM2: [250, 400], minimum: 2000 },
};

const fmt = (n) => n.toLocaleString('sr-Latn-RS');
export const money = ([a, b]) => `${fmt(a)} – ${fmt(b)} RSD`;

// Prikazano ispod svake usluge. Isti izvor kao kalkulator.
export const services = [
  {
    slug: 'dubinsko-pranje-namestaja',
    name: 'Dubinsko pranje nameštaja',
    short: 'Garniture, fotelje, jastuci i tapacirani nameštaj, na vašoj adresi.',
    metaTitle: 'Dubinsko pranje nameštaja na adresi | ClearNEST',
    metaDesc: 'Dubinsko pranje nameštaja ekstrakcijom: garniture, fotelje, stolice i dušeci. Dolazimo na vašu adresu, bezbedno za decu i ljubimce. Zatražite besplatnu procenu.',
    h1: 'Dubinsko pranje nameštaja na vašoj adresi',
    lead: 'Prašina, znoj, mrlje od pića i dlake ljubimaca ne ostaju na površini. Uvlače se u penu i vlakna. Zato običan usisivač i vlažna krpa ne pomažu: nameštaj izgleda bolje dan-dva, pa se mirisi i fleke vrate.',
    body: [
      'Dubinsko pranje ekstrakcijom radi u dva koraka. Prvo nanosimo rastvor koji razlaže nečistoće u vlaknima, zatim mašina visoke usisne snage izvlači rastvor zajedno sa prljavštinom. Voda ne ostaje u tapacirungu, pa se materijal suši znatno brže nego kod ručnog pranja.',
      'Radimo na vašoj adresi, tako da nameštaj ne selite. Pre početka proverimo vrstu materijala i testiramo sredstvo na skrivenom delu, kako bismo izbegli bojenje ili skupljanje tkanine.',
    ],
    includes: ['Ugaone garniture i na razvlačenje', 'Trosedi, dvosedi i fotelje', 'Stolice, taburei i tapacirani uzglavlja kreveta', 'Dušeci i jastuci', 'Tretman mrlja od kafe, vina, hrane i masnoće', 'Neutralisanje mirisa ljubimaca i duvanskog dima'],
    steps: [
      ['Pregled i procena', 'Proveravamo materijal, stepen zaprljanosti i vrstu mrlja, pa dogovaramo konačnu cenu pre rada.'],
      ['Usisavanje i predtretman', 'Uklanjamo suvu prašinu i dlake, pa nanosimo sredstvo na zaprljana mesta.'],
      ['Ekstrakcija', 'Mašina raspršuje rastvor i istovremeno ga usisava zajedno sa nečistoćom.'],
      ['Završna provera', 'Pregledamo rezultat sa vama, posavetujemo kako da ubrzate sušenje i kako da održavate nameštaj.'],
    ],
    priceKeys: ['ugaona', 'trosed', 'dvosed', 'fotelja', 'stolica'],
    faq: [
      ['Da li dubinsko pranje može da ošteti tapacirung?', 'Pre rada proveravamo oznaku na nameštaju i testiramo sredstvo na skrivenom delu. Za materijale koji ne podnose vlagu (na primer neke vrste svile ili kože) birate drugi tretman ili vam to unapred kažemo.'],
      ['Koliko dugo traje pranje jedne garniture?', 'Trosed ili dvosed obično traje oko sat vremena, a veća ugaona garnitura do dva sata, zavisno od zaprljanosti.'],
    ],
    related: ['ciscenje-troseda-dvoseda-i-ugaonih-garnitura', 'ciscenje-dusek', 'ciscenje-stolica-i-separea'],
  },
  {
    slug: 'ciscenje-dusek',
    name: 'Čišćenje dušeka',
    short: 'Uklanjamo grinje, znoj, mrlje i neprijatne mirise iz dušeka.',
    metaTitle: 'Čišćenje dušeka na adresi, mrlje i mirisi | ClearNEST',
    metaDesc: 'Dubinsko čišćenje dušeka na vašoj adresi: uklanjanje mrlja, mirisa, znoja i prašine. Bezbedno za bebe i alergičare. Besplatna procena preko fotografije.',
    h1: 'Čišćenje dušeka: sveži krevet bez mrlja i mirisa',
    lead: 'Na dušeku provodimo trećinu života. Vremenom upija znoj, prašinu, ćelije kože i tečnosti, a to se ne vidi dok ne nastane mrlja ili miris.',
    body: [
      'Dušek ne može da se opere u mašini niti da se iscedi, pa ga čistimo ekstrakcijom: nanosimo mali, kontrolisan nivo rastvora i odmah ga usisavamo. Time uklanjamo nečistoće iz gornjih slojeva, a dušek ne ostaje mokar.',
      'Ako imate bebu, malo dete ili ljubimca koji je napravio nezgodu, nazovite nas što pre. Sveže mrlje se uklanjaju znatno lakše od starih.',
    ],
    includes: ['Bračni i jednosedi dušeci', 'Dušeci dečjih kreveta i krevetaca', 'Mrlje od urina, krvi, kafe i znoja', 'Neutralisanje mirisa', 'Obe strane dušeka po dogovoru', 'Tapacirana uzglavlja i podnice kreveta'],
    steps: [
      ['Pregled', 'Procenjujemo vrstu dušeka i vrstu mrlja, a vama dajemo okvirnu cenu.'],
      ['Predtretman mrlja', 'Posebno tretiramo upečatljive mrlje pre glavnog pranja.'],
      ['Ekstrakcija', 'Mašina izvlači rastvor i nečistoće iz pene i tekstila.'],
      ['Sušenje', 'Dajemo savet o provetravanju i sušenju, da dušek bude spreman za spavanje isti dan ili sledeće veče.'],
    ],
    priceKeys: ['dusek1', 'dusek2'],
    faq: [
      ['Mogu li da spavam na dušeku isti dan?', 'Najčešće da, uz dobro provetravanje. Prosečno sušenje traje 3 do 6 sati, zavisno od temperature i vlažnosti prostorije.'],
      ['Da li čišćenje uklanja stare mrlje od urina?', 'Svež trag se uklanja gotovo u celosti. Stare, već osušene mrlje često jako posvetle, ali uspeh zavisi od starosti mrlje i da li je tretirana kućnim hemikalijama. To vam kažemo pre početka.'],
    ],
    related: ['dubinsko-pranje-namestaja', 'ciscenje-troseda-dvoseda-i-ugaonih-garnitura', 'ciscenje-tepiha-i-itisona'],
  },
  {
    slug: 'ciscenje-tepiha-i-itisona',
    name: 'Čišćenje tepiha i itisona',
    short: 'Dubinsko čišćenje tepiha i zidnog itisona bez iznošenja iz kuće.',
    metaTitle: 'Čišćenje tepiha i itisona na licu mesta | ClearNEST',
    metaDesc: 'Dubinsko čišćenje tepiha i itisona na licu mesta: uklanjanje mrlja, prašine i mirisa, brzo sušenje. Cena po kvadratnom metru, besplatna procena.',
    h1: 'Čišćenje tepiha i itisona na licu mesta',
    lead: 'Tepih je najveći filter u kući: hvata prašinu, blato, dlake i alergene. Usisivač skida samo površinski sloj.',
    body: [
      'Tepihe i zidni itison čistimo ekstrakcijom na licu mesta. Ne moraju da se iznose, vraćaju i dugo suše u dvorištu. Mašina usisava vodu odmah, pa je zadržana vlaga minimalna.',
      'Cena zavisi od površine i zaprljanosti. Pošaljite fotografiju i dimenzije, a mi vam dajemo okvirnu cenu.',
    ],
    includes: ['Zidni itison po kvadratnom metru', 'Tepisi od sintetike i vune (po proceni materijala)', 'Staze za hodnike i stepeništa', 'Mrlje od kafe, vina, blata i masnoće', 'Tragovi ljubimaca i neprijatni mirisi'],
    steps: [
      ['Merenje i procena', 'Merimo površinu i procenjujemo materijal i mrlje.'],
      ['Usisavanje', 'Skidamo suvu prašinu i dlake iz dubine vlakana.'],
      ['Ekstrakcija', 'Tretiramo celu površinu ravnomerno, pa usisavamo.'],
      ['Sušenje', 'Preporučujemo provetravanje ili ventilator za brže sušenje.'],
    ],
    priceKeys: [],
    priceNote: 'tepih',
    faq: [
      ['Kako se računa cena čišćenja tepiha?', 'Po kvadratnom metru, uz minimalan iznos porudžbine. Tačnu cenu dajemo na osnovu površine, zaprljanosti i materijala.'],
      ['Da li čistite i vunene tepihe?', 'Da, uz proveru materijala i blaže sredstvo. Kod vrlo vrednih ili antikvarnih tepiha unapred dogovaramo način rada.'],
    ],
    related: ['dubinsko-pranje-namestaja', 'ciscenje-dusek', 'ciscenje-lokala-i-poslovnih-prostora'],
  },
  {
    slug: 'ciscenje-troseda-dvoseda-i-ugaonih-garnitura',
    name: 'Čišćenje troseda, dvoseda i ugaonih garnitura',
    short: 'Trosedi, dvosedi i ugaone garniture: mrlje, mirisi i prašina uklonjeni.',
    metaTitle: 'Čišćenje trosed, dvosed i ugaonih garnitura | ClearNEST',
    metaDesc: 'Dubinsko čišćenje troseda, dvoseda i ugaonih garnitura na vašoj adresi. Uklanjamo mrlje, prašinu i mirise, brzo sušenje. Cena od — pogledajte okvirni cenovnik.',
    h1: 'Čišćenje troseda, dvoseda i ugaonih garnitura',
    lead: 'Garnitura je mesto gde se jede, spava, igra i gleda televizija. Zato je najčešće i najzaprljanija stvar u dnevnoj sobi.',
    body: [
      'Čistimo sve vrste garnitura: tkanina, mikrofiber, šenil i kombinovane. Ugaone garniture i one na razvlačenje čistimo sa svih strana, uključujući sedišta, naslone, rukohvate i, po dogovoru, unutrašnjost ležaja.',
      'Za tačnu cenu nam pošaljite dve do tri fotografije i pitajte nas za sedna mesta. Cena zavisi od broja sedišta, materijala i zaprljanosti.',
    ],
    includes: ['Trosedi i dvosedi', 'Ugaone garniture i garniture na razvlačenje', 'Fotelje i tabure', 'Dekorativni jastuci', 'Mrlje od hrane, pića, masti i olovke', 'Dlake i mirisi ljubimaca'],
    steps: [
      ['Fotografije i okvirna cena', 'Pošaljete slike preko forme, dobijate okvirnu cenu za 15 minuta.'],
      ['Predtretman', 'Mrlje tretiramo pre dubinskog pranja.'],
      ['Ekstrakcija', 'Sedišta, naslone i rukohvate peremo i usisavamo.'],
      ['Preporuke', 'Dobijate savet kako da održavate garnituru i šta izbegavati.'],
    ],
    priceKeys: ['ugaona', 'trosed', 'dvosed', 'fotelja'],
    faq: [
      ['Koliko košta čišćenje ugaone garniture?', 'Okvirno od 4.500 do 6.500 RSD, zavisno od veličine, materijala i zaprljanosti. Tačnu cenu dajemo posle fotografija.'],
      ['Da li se garnitura može čistiti ako nema oznaku za pranje?', 'Da, testiramo sredstvo na skrivenom delu. Ako materijal ne podnosi vlagu, unapred vam predlažemo drugi postupak.'],
    ],
    related: ['dubinsko-pranje-namestaja', 'ciscenje-stolica-i-separea', 'ciscenje-dusek'],
  },
  {
    slug: 'ciscenje-stolica-i-separea',
    name: 'Čišćenje stolica i separea',
    short: 'Stolice, separei i tapacirane klupe za domaćinstva, ugostitelje i kancelarije.',
    metaTitle: 'Čišćenje stolica i separea, kafići i restorani | ClearNEST',
    metaDesc: 'Čišćenje tapaciranih stolica i separea u kafićima, restoranima i kancelarijama. Brzo sušenje, rad van radnog vremena. Cena po komadu, popust za veće količine.',
    h1: 'Čišćenje stolica i separea',
    lead: 'Tapacirane stolice i separei u lokalima su svakodnevno u kontaktu sa hranom, pićem i velikim brojem ljudi. Mrlje i miris odbijaju goste.',
    body: [
      'Radimo u dogovoreno vreme, najčešće pre otvaranja ili posle zatvaranja, tako da lokal radi bez prekida. Sušenje je dovoljno brzo da se prostor koristi isti dan.',
      'Cena se računa po komadu za stolice i po dužnom metru ili sedištu za separee. Za veće količine dogovaramo posebnu cenu.',
    ],
    includes: ['Tapacirane stolice i taburei', 'Separei i ugaone klupe', 'Stolice u učionicama, čekaonicama i kancelarijama', 'Kućne trpezarijske stolice'],
    steps: [
      ['Dogovor termina', 'Zakazujemo vreme kada lokal ne radi.'],
      ['Predtretman', 'Mrlje od masti, pića i hrane tretiramo posebno.'],
      ['Ekstrakcija', 'Svaku stolicu i sedište peremo i usisavamo.'],
      ['Provera', 'Prolazimo kroz prostor sa vama pre odlaska.'],
    ],
    priceKeys: ['stolica'],
    faq: [
      ['Imate li popust za veći broj stolica?', 'Da. Za deset i više komada ili za ceo lokal dogovaramo posebnu cenu.'],
      ['Da li možete da radite noću ili vikendom?', 'Da, termin dogovaramo prema radnom vremenu vašeg lokala.'],
    ],
    related: ['ciscenje-lokala-i-poslovnih-prostora', 'dubinsko-pranje-namestaja', 'ciscenje-tepiha-i-itisona'],
  },
  {
    slug: 'ciscenje-enterijera-automobila',
    name: 'Čišćenje enterijera automobila',
    short: 'Sedišta, patosnice, gepek i vrata: dubinsko čišćenje enterijera vozila.',
    metaTitle: 'Čišćenje enterijera automobila, sedišta i patosnice | ClearNEST',
    metaDesc: 'Dubinsko čišćenje enterijera automobila na vašoj adresi: sedišta, patosnice, gepek i vrata. Uklanjamo mrlje i mirise. Cena zavisi od klase vozila.',
    h1: 'Čišćenje enterijera automobila na vašoj adresi',
    lead: 'Sedišta u automobilu upijaju znoj, hranu, piće i prašinu sa puta, a u zatvorenom prostoru se mirisi zadržavaju.',
    body: [
      'Dolazimo do vašeg automobila: ispred kuće, firme ili garaže. Potrebni su nam pristup struji i čista voda. Dubinski perem tekstilna sedišta, patosnice, gepek i unutrašnje obloge vrata.',
      'Cena zavisi od klase vozila (gradski, limuzina, SUV ili monovolumen) i od obima: samo sedišta ili kompletan enterijer.',
    ],
    includes: ['Tekstilna sedišta i naslone za glavu', 'Patosnice i tepisi', 'Gepek', 'Obloge vrata i tapacirani plafon (po dogovoru)', 'Dečija sedišta (po dogovoru)', 'Neutralisanje mirisa'],
    steps: [
      ['Pregled vozila', 'Procenjujemo materijal i mrlje, dogovaramo obim rada.'],
      ['Usisavanje', 'Skidamo prašinu, pesak i dlake.'],
      ['Ekstrakcija', 'Peremo i usisavamo sedišta i patosnice.'],
      ['Sušenje', 'Preporučujemo ostavljanje otvorenih prozora ili provetravanje.'],
    ],
    priceKeys: [],
    priceNote: 'auto',
    faq: [
      ['Da li radite i kožna sedišta?', 'Fokus nam je dubinsko čišćenje tekstila. Kožna sedišta čistimo drugačijim postupkom, pa to unapred proverite sa nama.'],
      ['Koliko dugo traje čišćenje automobila?', 'Samo sedišta oko sat vremena, a kompletan enterijer dva do tri sata.'],
    ],
    related: ['dubinsko-pranje-namestaja', 'ciscenje-tepiha-i-itisona', 'ciscenje-dusek'],
  },
  {
    slug: 'ciscenje-lokala-i-poslovnih-prostora',
    name: 'Čišćenje lokala i poslovnih prostora',
    short: 'Dubinsko čišćenje tapaciranog nameštaja i podova u lokalima i kancelarijama.',
    metaTitle: 'Čišćenje lokala i poslovnih prostora, itison | ClearNEST',
    metaDesc: 'Dubinsko čišćenje tepiha, itisona i tapaciranog nameštaja u lokalima, kancelarijama i hotelima. Rad van radnog vremena, ponuda po prostoru i ugovor.',
    h1: 'Čišćenje lokala i poslovnih prostora',
    lead: 'Čist prostor je prvi utisak koji gosti i klijenti dobijaju. Tapacirani nameštaj i itison u radnim prostorima brzo gube izgled.',
    body: [
      'Čistimo kancelarije, čekaonice, hotelske sobe, restorane, kafiće, ordinacije i učionice. Radimo u dogovoreno vreme da ne ometamo rad, a veće prostore radimo u jednom prolazu.',
      'Za redovne klijente nudimo ugovor sa fiksnim terminima. Pošaljite fotografije prostora i kvadraturu pa dobijate ponudu.',
    ],
    includes: ['Itison i tepisi u kancelarijama', 'Tapacirane stolice i fotelje', 'Separei i klupe u ugostiteljstvu', 'Hotelski i pansionski nameštaj', 'Čekaonice i ordinacije', 'Periodično održavanje po ugovoru'],
    steps: [
      ['Ponuda', 'Procenjujemo prostor iz fotografija ili obilaskom i šaljemo ponudu.'],
      ['Dogovor termina', 'Radimo van radnog vremena.'],
      ['Izvođenje', 'Čistimo po zonama, uz minimalno ometanje.'],
      ['Primopredaja', 'Zajedno prolazimo kroz prostor.'],
    ],
    priceKeys: ['stolica'],
    priceNote: 'tepih',
    faq: [
      ['Da li izdajete račun za pravna lica?', 'Da, izdajemo račun za pravna lica i preduzetnike.'],
      ['Možete li da održavate prostor periodično?', 'Da, dogovaramo mesečne ili kvartalne termine po ugovoru.'],
    ],
    related: ['ciscenje-stolica-i-separea', 'ciscenje-tepiha-i-itisona', 'dubinsko-pranje-namestaja'],
  },
];

// Opšta pitanja (početna + /pitanja/). Tekst preuzet iz vašeg nacrta.
export const faq = [
  ['Koliko vremena je potrebno da se nameštaj osuši nakon pranja?', 'Prosečno vreme sušenja je između 3 i 6 sati, u zavisnosti od temperature u prostoriji, vlažnosti vazduha i vrste materijala. Zahvaljujući mašinama visoke usisne snage, izvlačimo do 90% vlage tokom samog procesa.'],
  ['Da li su sredstva koja koristite bezbedna za decu i kućne ljubimce?', 'Da. Koristimo profesionalna, ekološka i dermatološki testirana sredstva koja ne ostavljaju štetne rezidue niti neugodne mirise.'],
  ['Da li se dolazak na adresu dodatno naplaćuje?', 'Za ugovorene poslove na teritoriji grada dolazak je besplatan. Za lokacije van gradske zone postoji minimalan iznos porudžbine ili simbolična nadoknada za putni trošak, o čemu vas obaveštavamo pre potvrdnog zakazivanja.'],
  ['Šta je potrebno da pripremim pre vašeg dolaska?', 'Ništa posebno. Važno je samo da obezbedite prilaz komadu nameštaja koji se pere i pristup struji i čistoj vodi.'],
  ['Da li dubinsko pranje uklanja sve mrlje i neprijatne mirise?', 'Uklanjamo do 95% mrlja (uključujući fleke od hrane, pića i svakodnevne prljavštine) i neutrališemo neprijatne mirise, poput mirisa ljubimaca ili duvanskog dima. Uspeh zavisi od starosti mrlje i da li je ranije tretirana neadekvatnim kućnim hemikalijama.'],
  ['Koliko košta dubinsko pranje?', 'Cena zavisi od vrste i veličine komada i od zaprljanosti. Na stranici procene dobijate okvirnu cenu odmah, a tačnu cenu posle fotografija, u roku od 15 minuta.'],
];

export const benefits = [
  ['Ekološka i dermatološki testirana hemija', 'Sredstva koja ne ostavljaju rezidue, bezbedna za decu i ljubimce.'],
  ['Snažna ekstrakcija, brzo sušenje', 'Mašina izvlači većinu vlage, pa se tekstil suši za nekoliko sati.'],
  ['Dolazak na vašu adresu', 'U ugovoreno vreme, sa svom opremom. Ništa ne iznosite.'],
];

// Recenzije: ubacujte SAMO prave, uz dozvolu autora. Prazno = sekcija i schema se ne prikazuju.
// { author: 'Ime P.', rating: 5, text: '…', date: '2026-10-01' }
export const reviews = [];

// Pre/posle galerija: { before: '/img/gal/1-pre.webp', after: '/img/gal/1-posle.webp', alt: 'Opis', w: 800, h: 600, caption: 'Trosed, mrlja od kafe' }
// Prazno = sekcija se ne prikazuje. Fotografije stavite u static/img/gal/.
export const gallery = [];
